import logging
import argparse
from openstack import neutron
import sys
import time


def str_to_list(string):
    return string.split(',')


parser = argparse.ArgumentParser(description='create router with subnets.')
parser.add_argument('cidrs', type=str_to_list,
                    help="The cidr of subnets, example: CIDR1,CIDR2")
parser.add_argument("-d", "--debug", action="store_true", dest="debug",
                    help="Show debug messages.")


LOG = logging.RootLogger(level=logging.INFO)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
LOG.addHandler(stream_handler)


def create_router_with_subnets(cidrs):
    LOG.info('Create router with subnets %s', args.cidrs)
    n_client = neutron.NeutronClient()
    time_now = time.time()
    router = n_client.create_router({'name': 'router-%s' % time_now})
    LOG.info('Created router %s', router['name'])

    num = 1
    for cidr in args.cidrs:
        network = n_client.create_network({
            'name': 'network-%s-%s' % (time_now, num)})
        LOG.info('Created network %s', network['name'])
        subnet = n_client.create_subnet({
            'network_id': network['id'],
            'name': 'subnet-%s-%s' % (time_now, num),
            'cidr': cidr,
            'ip_version': 4})
        LOG.info('Created subnet %s', subnet['name'])

        n_client.add_router_interface(router['id'], subnet['id'])
        LOG.info('Added subnet %s to router %s',
                 subnet['name'], router['name'])
        num += 1


if __name__ == "__main__":
    args = parser.parse_args()
    if not args.cidrs:
        parser.print_help()
        sys.exit(1)
    if args.debug:
        LOG.setLevel(logging.DEBUG)

    try:
        create_router_with_subnets(args.cidrs)
    except Exception as e:
        LOG.exception(e)
        sys.exit(1)
