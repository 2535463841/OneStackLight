from openstack import keystone
from openstack.api import networking as net_api
from common import config
from common import httpclient
from common import exceptions


NEUTRON_CONF = config.CONF.neutron


RESOURCE_URL = {
    'router': '/%s/routers',
    'network': '/%s/networks',
    'subnet': '/%s/subnets',
    'port': '/%s/ports',
}


class NeutronClient(httpclient.HttpClient):

    def __init__(self):
        super(NeutronClient, self).__init__(NEUTRON_CONF.scheme,
                                            NEUTRON_CONF.host,
                                            NEUTRON_CONF.port)
        self.api_version = NEUTRON_CONF.api_version
        self.identity = keystone.get_identity_manager()

        self.router_api = net_api.Router(self, self.api_version)
        self.network_api = net_api.Network(self, self.api_version)
        self.subnet_api = net_api.Subnet(self, self.api_version)
        self.port_api = net_api.Port(self, self.api_version)
        self.security_group_api = net_api.SecurityGroup(self, self.api_version)

        self.register_methods()

    def register_methods(self):
        for r in RESOURCE_URL:
            setattr(self, 'get_%s' % r, self._make_get_method(r))
            setattr(self, 'list_%s' % r, self._make_list_method(r))
            setattr(self, 'create_%s' % r, self._make_create_method(r))
            setattr(self, 'update_%s' % r, self._make_update_method(r))
            setattr(self, 'delete_%s' % r, self._make_delete_method(r))

    def _get_resource_url(self, resource):
        return RESOURCE_URL[resource] % self.api_version

    def _get_resource_id_url(self, resource, resource_id):
        return RESOURCE_URL[resource] % self.api_version + "/%s" % resource_id

    def _make_get_method(self, resource):
        api = getattr(self, '{}_api'.format(resource))

        def _get(resource_id):
            return api.get(resource_id)

        return _get

    def _make_list_method(self, resource):
        api = getattr(self, '{}_api'.format(resource))

        def _list(filters=None):
            return api.list(filters)

        return _list

    def _make_create_method(self, resource):
        api = getattr(self, '{}_api'.format(resource))

        def _create(params):
            return api.create(params)
        return _create

    def _make_update_method(self, resource):
        api = getattr(self, '{}_api'.format(resource))

        def _update(params):
            return api.create(params)
        return _update

    def _make_delete_method(self, resource):
        api = getattr(self, '{}_api'.format(resource))

        def _delete(resource_id):
            return api.delete(resource_id)
        return _delete

    @property
    def headers(self):
        return {
            "Content-Type": "application/json",
            "X-Auth-Token": self.identity.token_id
        }

    def add_router_interface(self, router_id, subnet_id=None, port_id=None):
        if subnet_id:
            body = {'subnet_id': subnet_id}
        elif port_id:
            body = {'port_id': port_id}
        else:
            raise exceptions.InterfacesNotFound()
        return self.router_api.add_interface(router_id, body)

    def remove_router_interface(self, router_id, subnet_id=None, port_id=None):
        if subnet_id:
            body = {'subnet_id': subnet_id}
        elif port_id:
            body = {'port_id': port_id}
        else:
            raise exceptions.InterfacesNotFound()
        return self.router_api.delete_interface(router_id, body)

    def get_router_interfaces(self, router_id):
        return self.port_api.list({'device_id': router_id,
                                  'device_owner': 'network:router_interface'})
