import time
import six
import abc
from common import config
from common import constants
from common import httpclient


KEYSTONE_CONF = config.CONF.keystone
IDENTITY_CONF = config.CONF.identity


class Token(object):

    def __init__(self, token_id):
        self.id = token_id
        self.expires_at = time.time() + KEYSTONE_CONF.token_timeout


@six.add_metaclass
class KeystoneClientBase(httpclient.HttpClient):

    def __init__(self, conf):
        self.token = None
        super(KeystoneClientBase, self).__init__(conf.scheme,
                                                 conf.host,
                                                 conf.port)

    @property
    def token_id(self):
        if not self.token or time.time() >= self.tokenexpires_at:
            self.token = Token(self.get_token_id)
        return self.token.id

    @abc.abstractmethod
    def get_token_id(self):
        pass


class KeystoneClientV2(KeystoneClientBase):

    def __init__(self, conf, identity_conf):
        self.api_version = constants.KEYSTONE_VERSION_V2

        self.project_domain = identity_conf.project_domain
        self.project_name = identity_conf.project_name
        self.user_domain = identity_conf.user_domain
        self.user_name = identity_conf.user_name
        self.user_password = identity_conf.user_password

        super(KeystoneClientV2, self).__init__(conf)

    def get_token_id(self):
        return self._token_issue().headers.get('x-subject-token')

    def _token_issue(self):
        body = {"auth": {
                    "scope": {
                        "project": {
                            "domain": {"name": self.project_domain},
                            "name": self.project_name
                        }
                    },
                    "identity": {
                        "password": {
                            "user": {
                                "domain": {"name": self.user_domain},
                                "password": self.user_password,
                                "name": self.user_name
                            }
                        },
                        "methods": ["password"]
                    }
                }}
        resp = self.post('/%s/auth/tokens' % self.api_version,
                         body=body)
        return resp


class KeystoneClientV3(KeystoneClientBase):

    def __init__(self, conf, identity_conf):
        self.api_version = constants.KEYSTONE_VERSION_V3

        self.project_domain = identity_conf.project_domain
        self.project_name = identity_conf.project_name
        self.user_domain = identity_conf.user_domain
        self.user_name = identity_conf.user_name
        self.user_password = identity_conf.user_password

        super(KeystoneClientV3, self).__init__(conf)

    def get_token_id(self):
        return self._token_issue().headers.get('x-subject-token')

    def _token_issue(self):
        body = {"auth": {
                    "scope": {
                        "project": {
                            "domain": {"name": IDENTITY_CONF.project_domain},
                            "name": IDENTITY_CONF.project_name
                        }
                    },
                    "identity": {
                        "password": {
                            "user": {
                                "domain": {"name": IDENTITY_CONF.user_domain},
                                "password": IDENTITY_CONF.user_password,
                                "name": IDENTITY_CONF.user_name
                            }
                        },
                        "methods": ["password"]
                    }
                }}
        resp = self.post('/%s/auth/tokens' % self.api_version,
                         body=body)
        return resp


def get_identity_manager():
    if str(KEYSTONE_CONF.api_version) == constants.KEYSTONE_VERSION_V3:
        return KeystoneClientV3(KEYSTONE_CONF, IDENTITY_CONF)
    else:
        return KeystoneClientV2(KEYSTONE_CONF, IDENTITY_CONF)
