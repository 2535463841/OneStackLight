
class APIBase(object):

    resource = 'base_api'

    def __init__(self, http_client, api_version):
        self.http_client = http_client
        self.api_version = api_version

    def create(self, params):
        url = '/{}/{}'.format(self.api_version, self.resource)
        resp = self.http_client.post(url, params)
        return resp.content.values()[0]

    def list(self, filters=None):
        if filters:
            params = []
            for key, value in filters.items():
                params.append('%s=%s' % (key, value))
            params = "?" + "&".join(params)
        else:
            params = ''
        url = '/{}/{}{}'.format(self.api_version, self.resource, params)
        resp = self.http_client.get(url)
        return resp.content.values()[0]

    def update(self, resource_id, params):
        url = '/{}/{}/{}'.format(self.api_version, self.resource, resource_id)
        resp = self.http_client.put(url, params)
        return resp.content.values()[0]

    def get(self, resource_id):
        url = '/{}/{}/{}'.format(self.api_version, self.resource, resource_id)
        resp = self.http_client.get(url)
        return resp.content.values()[0]

    def delete(self, resource_id):
        url = '/{}/{}/{}'.format(self.api_version, self.resource, resource_id)
        resp = self.http_client.delete(url)
        return resp.content.values()[0]
