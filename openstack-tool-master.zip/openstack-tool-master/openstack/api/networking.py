from openstack.api import base


class Router(base.APIBase):
    resource = 'routers'

    def add_interface(self, router_id, body):
        resp = self.put('/{}/{}/{}/add_router_interface'.format(
                            self.api_version, self.resource, router_id),
                        body=body)
        return resp.content

    def delete_interface(self, router_id, body):
        resp = self.put('/{}/{}/{}/add_router_interface'.format(
                            self.api_version, self.resource, router_id),
                        body=body)
        return resp.content


class Network(base.APIBase):
    resource = 'networks'


class Subnet(base.APIBase):
    resource = 'subnets'


class Port(base.APIBase):
    resource = 'ports'


class SecurityGroup(base.APIBase):
    resource = 'security_groups'


class SecurityGroupRule(base.APIBase):
    resource = 'security_group_rules'


class Firewall(base.APIBase):
    resource = 'firewalls'


class FirewallPolicy(base.APIBase):
    resource = 'firewall_policies'


class FirewallRule(base.APIBase):
    resource = 'firewall_rules'
