#!/usr/bin/python
# coding: utf-8
import os
import platform
import ConfigParser
import urllib2


DEFAULT_SOURCES = [
    ('中国科技大学',
     'https://pypi.mirrors.ustc.edu.cn/simple', 'pypi.mirrors.ustc.edu.cn'),
    ('清华大学',
     'https://pypi.tuna.tsinghua.edu.cn/simple', 'pypi.tuna.tsinghua.edu.cn'),
    ('豆瓣',
     'https://pypi.douban.com/simple', 'pypi.douban.com'),
    ('阿里云',
     'http://mirrors.aliyun.com/pypi/simple/', 'mirrors.aliyun.com')
]


class PipSource(object):

    def __init__(self, index_url, trusted_host, name=None):
        self.index_url = index_url
        self.trusted_host = trusted_host
        self._name = name

    @property
    def name(self):
        return self._name if self._name else self.index_url

    def available(self):
        req = urllib2.Request(self.index_url)
        resp = urllib2.urlopen(req)
        return resp.code == 200

    def config(self):
        os_type = platform.system()
        if os_type == "Linux":
            pip_conf_dir = "%s/.pip" % os.path.expanduser('~')
            pip_conf_file = "%s/pip.conf" % pip_conf_dir
        elif os_type == "Windows":
            pip_conf_dir = "%s\\pip" % os.path.expanduser('~')
            pip_conf_file = "%s\\pip.ini" % pip_conf_dir
        else:
            print '系统类型是: %s，无法配置' % os_type
        config = ConfigParser.ConfigParser()
        config.add_section('global')
        config.add_section('install')
        config.set('global', 'index-url', self.index_url)
        config.set('install', 'trusted-host', self.trusted_host)
        with open(pip_conf_file, 'w') as f:
            config.write(f)


def main():
    print '配置 pip 源 ...'
    for name, url, trust in DEFAULT_SOURCES:
        pip_source = PipSource(url, trust, name)
        if pip_source.available():
            pip_source.config()
            print '源: %s，配置成功.' % pip_source.name
            break
        else:
            print '源: %s，配置失败.' % pip_source.name


if __name__ == '__main__':
    main()
