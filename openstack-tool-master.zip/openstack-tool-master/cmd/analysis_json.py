#! /usr/bin/python
import os
import sys
import json
import logging
import argparse

parser = argparse.ArgumentParser(description='analysis json file')
parser.add_argument('file', type=str,
                    help="The json file.")
parser.add_argument("-k", "--keys", default='', dest='keys',
                    help="get value by keys.")
parser.add_argument("-d", "--debug", action="store_true", dest="debug",
                    help="Show debug messages.")


class JsonAnalysis(object):

    def __init__(self, file):
        self. file = file
        self.json_obj = None

    def get_value(self, keys_list=[]):
        if not self.json_obj:
            if not os.path.isfile(self.file):
                raise Exception('%s is not a file.' % self.file)
            try:
                with open(self.file) as f:
                    self.json_obj = json.loads(f.read())
            except Exception as e:
                LOG.exception(e)

        value = self.json_obj
        for key in keys_list:
            if key in value:
                value = value.get(key)
            else:
                raise Exception('key %s is not found.' % key)
        return value


LOG_FORMATTER = '%(levelname)s: %(message)s'
LOG = logging.RootLogger(level=logging.INFO)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(logging.Formatter(LOG_FORMATTER))
LOG.addHandler(stream_handler)


if __name__ == "__main__":
    args = parser.parse_args()
    if args.debug:
        LOG.setLevel(logging.DEBUG)
    LOG.debug("Argument: %s", args)
    keys_list = [k for k in args.keys.split('.') if k != '']

    try:
        json_analysis = JsonAnalysis(args.file)
        if len(keys_list) > 0:
            LOG.debug('Get json value by: %s.', ' -> '.join(keys_list))
        value = json_analysis.get_value(keys_list=keys_list)
        LOG.debug('The value is:\n%s', value)
        json.dump(value, sys.stdout, indent=4)
        print ''
    except Exception as e:
        LOG.error(e)
        sys.exit(1)
