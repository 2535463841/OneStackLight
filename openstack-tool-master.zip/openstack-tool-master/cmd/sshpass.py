#! /usr/bin/python
import argparse
import logging
import sys
import paramiko
import socket
import getpass


parser = argparse.ArgumentParser(description='Execute cmd on remote '
                                             'host with password.')
parser.add_argument('command', type=str,
                    help="The host of ssh server.")
parser.add_argument("-H", "--host", required=True,
                    help="The host of ssh server.")
parser.add_argument("-P", "--port", default=22, type=int,
                    help="The port of ssh server.")
parser.add_argument("-u", "--user", default=getpass.getuser(),
                    help="The user for login.")
parser.add_argument("-p", "--password", default='',
                    help="The password for login.")
parser.add_argument("-t", "--timeout", default=3, type=int,
                    help="Timeout of connection.")
parser.add_argument("-g", "--get-pty", action="store_true",
                    help="Use pty.")
parser.add_argument("-d", "--debug", action="store_true",
                    help="Show debug messages.")


class SSHPassClient(object):

    def __init__(self, host, user, password, port=22, timeout=None):
        self.host = host
        self.user = user
        self.password = password
        self.port = port
        self.timeout = timeout
        self.client = paramiko.SSHClient()
        self.client.load_system_host_keys()
        self.client.set_missing_host_key_policy(
            paramiko.AutoAddPolicy())

    def execute(self, command, get_pty=False):
        self.client.connect(hostname=self.host,
                            port=self.port,
                            username=self.user,
                            password=self.password,
                            timeout=self.timeout)
        result = self.client.exec_command(command, get_pty=get_pty)
        error = result[2].read().strip()
        if error != "":
            return error
        else:
            return result[1].read().strip()


LOG_FORMATTER = '%(levelname)s: %(message)s'
LOG = logging.RootLogger(level=logging.INFO)
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(logging.Formatter(LOG_FORMATTER))
LOG.addHandler(stream_handler)


if __name__ == "__main__":
    args = parser.parse_args()
    if args.debug:
        LOG.setLevel(logging.DEBUG)
    LOG.debug("Argument: %s", args)
    if not (args.host and args.user):
        parser.print_help()
        sys.exit(1)
    try:
        ssh_client = SSHPassClient(args.host, args.user, args.password,
                                   port=args.port,
                                   timeout=args.timeout)
        print ssh_client.execute(args.command, get_pty=args.get_pty)
    except socket.timeout:
        LOG.error('Connect to %s:%s timeout(%s seconds)',
                  args.host, args.port, args.timeout)
        sys.exit(1)
    except paramiko.ssh_exception.AuthenticationException:
        LOG.error('Authentication failed, user: %s password: "%s"',
                  args.user, args.password)
        sys.exit(1)
    except socket.error as e:
        LOG.error(e)
        sys.exit(1)
    except Exception as e:
        LOG.exception(e)
        sys.exit(1)
