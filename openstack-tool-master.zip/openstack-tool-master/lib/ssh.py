import paramiko
from common import log

LOG = log.LOG


class SshPassClient(object):

    def __init__(self, host, user, password, port=22, timeout=None):
        self.host = host
        self.user = user
        self.password = password
        self.port = port
        self.timeout = timeout
        self.client = paramiko.SSHClient()
        self.client.load_system_host_keys()
        self.client.set_missing_host_key_policy(
            paramiko.AutoAddPolicy())

    def exec_command(self, command, get_pty=False):
        command = ' '.join(command)
        LOG.info('Execute command in <%s>', self.host)
        LOG.info('CMD: %s', command)
        self.client.connect(hostname=self.host,
                            port=self.port,
                            username=self.user,
                            password=self.password,
                            timeout=self.timeout)
        in_info, out_info, err_info = self.client.exec_command(
            command, get_pty=get_pty)
        out = out_info.read().strip()
        error = err_info.read().strip()
        LOG.info('ERR:\n%s', error)
        LOG.info('OUT:\n%s', out)
        if error != "":
            return error
        else:
            return out
