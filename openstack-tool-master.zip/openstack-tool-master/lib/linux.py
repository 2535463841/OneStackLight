from lib import ssh

IP = 'ip'
ROUTE = 'route'
LS = 'ls'


class BaseCommand(object):

    def __init__(self, driver):
        self.driver = driver

# class LSWraper(BaseCommand):

#     def ll(self)

class IPWraper(BaseCommand):

    def a(self):
        return self.driver.exec_command([IP, 'a'])

    def link(self):
        return self.driver.exec_command([IP, 'link'])

    def route(self):
        return self.driver.exec_command([IP, 'route'])

    def netns(self):
        return self.driver.exec_command([IP, 'netns'])

    def neigh(self):
        return self.driver.exec_command([IP, 'neigh'])


class RouteWraper(BaseCommand):

    def list(self, numeric=False):
        cmd = [ROUTE]
        if numeric:
            cmd.append('-n')
        return self.driver.exec_command(cmd)


class Namespace(object):

    NETNS = 'netns'

    def __init__(self, sshclient):
        self.driver = sshclient
        self.ns = None
        self.ip = IPWraper(self)
        self.route = RouteWraper(self)

    def list(self, filter_regex=None):
        cmd = [IP, self.NETNS, 'list']
        if filter_regex:
            cmd.extend(['|', 'egrep', filter_regex])
        return self.driver.exec_command(cmd).split()

    def exist(self, ns_name):
        ns = self.list(filter_regex='^%s$' % ns_name)
        return len(ns) != 0

    def set_ns(self, ns_name):
        self.ns = ns_name

    def exit(self, ns_name):
        self.ns = None

    def exec_command(self, cmd):
        if not self.ns:
            raise Exception('current namespace not set.')
        base_cmd = [IP, self.NETNS, 'exec', self.ns]
        base_cmd.extend(cmd)
        return self.driver.exec_command(base_cmd)


class RemoteHost(ssh.SshPassClient):

    def __init__(self, **kargs):
        super(RemoteHost, self).__init__(**kargs)
        self.namespace = Namespace(self)
        self.ip = IPWraper(self)
        self.route = RouteWraper(self)

    def ls(self, path=None, options=[]):
        cmd = [LS]
        cmd.append(path) if path else None
        cmd.extend(options)
        return self.exec_command(cmd)

    def ll(self, path=None, options=[]):
        options.append('-l')
        return self.ls(path=path, options=options)
