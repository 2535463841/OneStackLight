import logging
import argparse
from openstack import neutron
from common import exceptions
import sys

global LOG

parser = argparse.ArgumentParser(description='create router with subnets.')
parser.add_argument('router', help="The cidr of subnets.")
parser.add_argument("-d", "--debug",
                    dest="debug",
                    action="store_true",
                    help="Show debug messages.")

n_client = neutron.NeutronClient()


def setup_log(level):
    global LOG
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(
        logging.Formatter('%(levelname)s: %(message)s'))
    LOG = logging.RootLogger(level=level)
    LOG.addHandler(stream_handler)


def delete_router_with_subnets(routers):
    for router in routers:
        LOG.info('Deleting router: %s(%s)', router['id'], router['name'])
        for port in n_client.get_router_interfaces(router['id']):
            n_client.remove_router_interface(router['id'], port_id=port['id'])
            LOG.info('Removed router interface %s', port['id'])
            n_client.delete_network(port['network_id'])
            LOG.info('Removed network %s', port['network_id'])
        n_client.delete_router(router['id'])
        LOG.info('Deleted router %s(%s)', router['id'], router['name'])


if __name__ == "__main__":
    args = parser.parse_args()
    if args.debug:
        setup_log(logging.DEBUG)
    else:
        setup_log(logging.INFO)
    if not args.router:
        parser.print_help()
        sys.exit(1)

    try:
        routers = [n_client.get_router(args.router)]
    except exceptions.Http404Error as e:
        LOG.error(e)
        routers = n_client.list_router(args.router)
    if len(routers) == 0:
        raise exceptions.RouterNotFound({'router': args.router})

    delete_router_with_subnets(args.routers)
