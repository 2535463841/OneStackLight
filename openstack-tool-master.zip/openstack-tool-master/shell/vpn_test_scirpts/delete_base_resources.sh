
TMP='./template'

routers=${TMP}/routers.txt
networks=${TMP}/networks.txt
subnets=${TMP}/subnets.txt
floatingips=${TMP}/floatingips.txt
vpns=${TMP}/vpns.txt


floatingip_line=`cat ${floatingips} |wc -l`
for i in `seq ${floatingip_line}`
do
    fip_id=`awk NR==${i} ${floatingips}  |awk -F , '{print $1}'`
    openstack floating ip delete ${fip_id}
    echo "INFO: Deleted floatingip ${fip_id}"
done

vpn_line=`cat ${vpns} |wc -l`
for i in `seq ${vpn_line}`
do
    vpn_id=`awk NR==${i} ${vpns}  |awk -F , '{print $1}'`
    openstack vpn service delete ${vpn_id}
    echo "INFO: Deleted vpn service ${vpn_id}"
done

router_line=`cat ${routers} |wc -l`
for i in `seq ${router_line}`
do
    router_id=`awk NR==${i} ${routers}`
    subnet_id=`awk NR==${i} ${subnets} |awk -F , '{print $1}'`
    openstack router remove subnet ${router_id} ${subnet_id}
    openstack subnet show ${subnet_id} |awk '/network_id/ {print %4}' |xargs -IID openstack network delete ID
    openstack router delete ${router_id}
    echo "INFO: Deleted router ${router_id}"
done
