
EXT_NET='ext-net'
TMP='./template'

function init()
{
    if [[ ! -d ${TMP} ]]; then
      mkdir ${TMP}
    fi
    routers=${TMP}/routers.txt
    networks=${TMP}/networks.txt
    subnets=${TMP}/subnets.txt
    ikepolcy=${TMP}/ikepolcy.txt
    ipsecpolicy=${TMP}/ipsecpolicy.txt
    floatingips=${TMP}/floatingips.txt
    vpns=${TMP}/vpns.txt

    cat /dev/null >  ${routers}
    cat /dev/null >  ${networks}
    cat /dev/null >  ${subnets}
    cat /dev/null >  ${ikepolcy}
    cat /dev/null >  ${ipsecpolicy}
    cat /dev/null >  ${floatingips}
    cat /dev/null >  ${vpns}
}

function setup_site()
{
    site_name=$1
    subnet_range=$2

    router_id=`openstack router create ${site_name}-router |awk '/ id / {print $4}'`
    if [[ ${router_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created router ${router_id}"
    echo ${router_id} >> ${routers}

    net_id=`openstack network create ${site_name}-network |awk '/ id / {print $4}'`
    if [[ ${net_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created network ${net_id}"
    echo ${net_id} >> ${networks}

    subnet_id=`openstack subnet create ${site_name}-subnet --network ${net_id} --subnet-range ${subnet_range} |awk '/ id / {print $4}'`
    if [[ ${subnet_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created subnet ${subnet_id}"
    echo "${subnet_id},${subnet_range}" >> ${subnets}

    openstack router add subnet ${router_id}  ${subnet_id}
    echo "INFO: Added subnet ${subnet_id} to ${router_id}"

    openstack router set ${router_id} --external-gateway ${EXT_NET}

    fip_id=`openstack floating ip create ${EXT_NET}| awk '/ id / {print $4}'`
    if [[ ${fip_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created floatingip ${fip_id}"
    fip_address=`openstack floating ip show ${fip_id} |awk '/ floating_ip_address / {print $4}'`
    echo "${fip_id},${fip_address}" >> ${floatingips}

    router_interfce=`openstack port list --device-owner 'network:router_interface' --router ${router_id} |awk '/subnet_id/ {print $2}'`
    openstack floating ip set ${fip_id} --port ${router_interfce}
    echo "INFO: Seted floatingip ${fip_id} to ${router_interfce}"

    vpn_id=`openstack vpn service create ${site_name}-vpn --router ${router_id} --subnet ${subnet_id} |awk '/ ID / {print $4}'`
    if [[ ${vpn_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created vpn service ${vpn_id}"
    echo "${vpn_id}" >> ${vpns}
}


init

setup_site 'left'  '192.168.1.0/24'
setup_site 'right' '192.168.2.0/24'
