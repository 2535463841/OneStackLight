
TMP='./template'

ikepolcy=${TMP}/ikepolcy.txt
ipsecpolicy=${TMP}/ipsecpolicy.txt
ipsecs=${TMP}/ipsecs.txt

ipsec_line=`cat ${ipsecs} |wc -l`
for i in `seq ${ipsec_line}`
do
  ipsec_id=`awk NR==${i} ${ipsecs}`
  openstack vpn ipsec site connection delete ${ipsec_id}
  echo "INFO: Deleted ipsec-site-connection ${ipsec_id}"
done

ikepolcy_line=`cat ${ikepolcy} |wc -l`
for i in `seq ${ikepolcy_line}`
do
    ikepolcy_id=`awk NR==${i} ${ikepolcy}`
    openstack vpn ike policy delete ${ikepolcy_id}
    echo "INFO: Deleted ikepolicy ${ikepolcy_id}"
done

ipsecpolicy_line=`cat ${ipsecpolicy} |wc -l`
for i in `seq ${ipsecpolicy_line}`
do
    ipsecpolicy_id=`awk NR==${i} ${ipsecpolicy}`
    openstack vpn ipsec policy delete ${ipsecpolicy_id}
    echo "INFO: Deleted ipsecpolicy ${ipsecpolicy_id}"
done
