
TMP='./template'

vpns=${TMP}/vpns.txt
routers=${TMP}/routers.txt
networks=${TMP}/networks.txt
subnets=${TMP}/subnets.txt
floatingips=${TMP}/floatingips.txt
ikepolcy=${TMP}/ikepolcy.txt
ipsecpolicy=${TMP}/ipsecpolicy.txt

ipsecs=${TMP}/ipsecs.txt


function init()
{
    if [[ ! -d ${TMP} ]]; then
      mkdir ${TMP}
    fi

    cat /dev/null >  ${ikepolcy}
    cat /dev/null >  ${ipsecpolicy}
    cat /dev/null >  ${ipsecs}
}

function create_policy()
{
    local ikepolcy_id=`openstack vpn ike policy create test-ikepolicy | awk '/ ID / {print $4}'`
    if [[ ${ikepolcy_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created ike policy ${ikepolcy_id}"
    echo "${ikepolcy_id}" >> ${ikepolcy}

    local ipsecpolcy_id=`openstack vpn ipsec policy create test-ipsecpolicy | awk '/ ID / {print $4}'`
    if [[ ${ipsecpolcy_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created ipsec policy ${ipsecpolcy_id}"
    echo "${ipsecpolcy_id}" >> ${ipsecpolicy}
}

function setup_ipsec_site()
{
    local site_name=$1
    local vpn_id=$2
    local peer_id=$3
    local peer_cidr=$4

    ipsec_id=`openstack vpn ipsec site connection create ${site_name}-ipsec --vpnservice ${vpn_id} --ikepolicy ${ikepolcy_id} --ipsecpolicy ${ipsecpolicy_id} --peer-id ${peer_id} --peer-address ${peer_id} --peer-cidr ${peer_cidr} --psk secret | awk '/\| ID / {print $4}'`

    if [[ ${ipsec_id} == "" ]]; then
      return 1
    fi
    echo "INFO: created ipsec site connection ${ipsec_id}"
    echo "${ipsec_id}" >> ${ipsecs}
}

init

create_policy

ikepolcy_id=`awk NR==1 ${ikepolcy}`
ipsecpolicy_id=`awk NR==1 ${ipsecpolicy}`

vpn_id=`awk NR==1 ${vpns}`
peer_id=`awk NR==2 ${floatingips} |awk -F , '{print $2}'`
peer_cidr=`awk NR==2 ${subnets} |awk -F , '{print $2}'`
setup_ipsec_site 'left' ${vpn_id} ${peer_id} ${peer_cidr}


vpn_id=`awk NR==2 ${vpns}`
peer_id=`awk NR==1 ${floatingips} |awk -F , '{print $2}'`
peer_cidr=`awk NR==1 ${subnets} |awk -F , '{print $2}'`
setup_ipsec_site 'right' ${vpn_id}  ${peer_id}  ${peer_cidr}
