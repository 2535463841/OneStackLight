# Create a router with multiple subnets

function echo_info()
{
    echo -e "\033[32m INFO:\033[0m" ${1}
}

function echo_error()
{
    echo -e "\033[31m ERROR:\033[0m" ${1}
}

if [[ $# -eq 0 ]]; then
  echo "Usage: sh ${0} <SUBNET_RANGES>"
  exit 1
fi

SUBNET_RANGES=$*
# NAME_PREFIX="test-`date +'%Y%m%d-%H%M%S'`"
NAME_PREFIX="test-`date +'%m%d-%H%M%S'`"

router_name="${NAME_PREFIX}-router"
router_id=`openstack router create ${router_name} |awk '/ id / {print $4}'`
if [[ "${router_id}" == "" ]]; then
  echo_error "created router ${router_name} failed!"
  exit 1
else
    echo_info "created router ${router_name}(${router_id}) ."
fi

num=0
for subnet_range in ${SUBNET_RANGES[*]}
do
  echo ''
  num=$((num + 1))
  net_name="${NAME_PREFIX}-network-${num}"
  net_id=`openstack network create ${net_name} |awk '/ id / {print $4}'`
  if [[ "${net_id}" == "" ]]; then
    echo_error "create ${net_name} failed!"
  else
    echo_info "create network ${net_id}(${net_name}) success."
  fi

  subnet_name="${NAME_PREFIX}-subnet-${num}"
  subnet_id=`openstack subnet create --network ${net_id} --name ${subnet_name}  --subnet-range ${subnet_range} |awk '/ id / {print $4}'`
  if [[ "${subnet_id}" == "" ]]; then
    echo_error "create ${subnet_name} failed!"
  else
    echo_info "created subnet ${subnet_id}(subnet_name)."
  fi
  openstack router add subnet ${router_id}  ${subnet_id} > /dev/null
  if [[ $? -eq 0 ]]; then
      echo_info "add ${subnet_name} to ${router_name} success."
  else
      echo_error "add ${subnet_name} to ${router_name} failed!"
  fi
done
