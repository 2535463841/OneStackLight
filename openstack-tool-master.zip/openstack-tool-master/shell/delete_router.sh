# delete router

function echo_info()
{
    echo -e "\033[32m INFO:\033[0m" ${1}
}

function echo_error()
{
    echo -e "\033[31m ERROR:\033[0m" ${1}
}

if [[ $# -ne 1 ]]; then
  echo "Usage: sh ${0} <ROUTER>"
  exit 1
fi
router=$1

router_id=`openstack router show ${router} 2>&1 |awk '/ id / {print $4}'`
if [[ "${router_id}" == "" ]]; then
  echo_error "router ${router} not found or there are multiple routers!"
  exit 1
fi

router_ports=`openstack port list --router ${router_id} --device-owner 'network:router_interface' |awk '/subnet_id/ {print $2}'`
for port in ${router_ports}
do
  openstack router remove port ${router_id} ${port} > /dev/null
  echo_info "removed router port ${port}"
done

openstack router delete ${router_id} > /dev/null
if [[ $? -eq 0 ]]; then
    echo_info "delete router ${router_id} success."
else
    echo_error "delete router ${router_id} failed!"
fi
