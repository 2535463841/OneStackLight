

class UnknownException(Exception):

    _message = 'Unknown exception'

    def __init__(self, args={}):
        super(UnknownException, self).__init__(self._message % args)


class Unauthorized(UnknownException):
    _message = 'Request is not Unauthorized,' \
               'please check identity configeration.'


class TokenNotFound(UnknownException):
    _message = 'Token is None'


class InterfacesNotFound(UnknownException):
    _message = 'Both subnet_id and port_id are None.'


class Http404Error(UnknownException):
    _message = 'Http 404 error.'


class RouterNotFound(UnknownException):
    _message = 'Router %(router)s not found.'
