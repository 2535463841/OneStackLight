import logging
from common import config


def setup_logging(log, conf):
    log.setLevel(conf.log_level)
    fh = logging.FileHandler(conf.log_file, mode='w')
    fh.setLevel(conf.log_level)
    fh.setFormatter(logging.Formatter(conf.log_format))
    log.addHandler(fh)


global LOG
LOG = logging.getLogger('openstack-tool')
setup_logging(LOG, config.CONF.log)
