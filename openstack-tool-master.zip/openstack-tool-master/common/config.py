import ConfigParser

global CONF


class Option(object):

    def __init__(self, name, default=None):
        super(Option, self).__init__()
        self.name = name
        self.default = default
        self.value = None

    def set_value(self, value):
        self.value = value

    def __str__(self):
        return str(self._value())

    def _value(self):
        if hasattr(self, 'value'):
            return self.value
        else:
            return self.default


class OptGroup(object):

    def __init__(self, name):
        super(OptGroup, self).__init__()
        self.name = name
        self._options = {}

    def add_opt(self, opt):
        self._options[opt.name] = opt

    def __getattr__(self, name):
        if name in self._options:
            return self._options[name]._value()
        else:
            raise Exception('No such option!')

    def options(self):
        return self._options.keys()

    def set_option_value(self, opt_name, value):
        self._options[opt_name].set_value(value)


class ConfigOpts(object):

    def __init__(self):
        super(ConfigOpts, self).__init__()
        self._groups = {}

    def __getattr__(self, name):
        if name in self._groups:
            return self._groups[name]
        else:
            raise Exception('No such group!')

    def register_opts(self, options, group=ConfigParser.DEFAULTSECT):
        for option in options:
            self.register_opt(option, group)

    def register_opt(self, option, group=ConfigParser.DEFAULTSECT):
        if group not in self._groups:
            self._groups[group] = OptGroup(group)
        self._groups[group].add_opt(option)

    def groups(self):
        return self._groups.keys()


def _init_configuration():
    log_opts = [
        Option('log_file', default='./test.log'),
        Option('log_level', default='INFO'),
        Option('log_format', default='%(asctime)s %(levelname)s %(message)s '
                                     '%(filename)s:%(lineno)d'),
    ]
    identity_opts = [
        Option('project_domain', default='Default'),
        Option('project_name', default=''),
        Option('user_domain', default='Default'),
        Option('user_name', default=''),
        Option('user_password', default=''),
    ]
    keystone_opts = [
        Option('scheme', default='http'),
        Option('host', default=''),
        Option('port', default=5000),
        Option('api_version', default='v3'),
    ]
    neutron_opts = [
        Option('scheme', default='http'),
        Option('host', default=''),
        Option('port', default=9696),
        Option('api_version', default='v2.0'),
    ]
    CONF.register_opts(options=log_opts, group='log')
    CONF.register_opts(options=identity_opts, group='identity')
    CONF.register_opts(options=keystone_opts, group='keystone')
    CONF.register_opts(options=neutron_opts, group='neutron')


def _load_configuration():
    services_conf = './config/servers.conf'
    parser = ConfigParser.ConfigParser()
    parser.read(services_conf)

    for group_name in CONF.groups():
        if parser.has_section(group_name):
            opt_group = getattr(CONF, group_name)
            for opt_name in getattr(CONF, group_name).options():
                if parser.has_option(group_name, opt_name):
                    opt_group.set_option_value(
                        opt_name, parser.get(group_name, opt_name))


global CONF
CONF = ConfigOpts()
_init_configuration()
_load_configuration()
