from openstack import neutron


n_client = neutron.NeutronClient()
print n_client.get_router_interfaces('1a1ba330-a909-4a6a-9a7b-e43ff2c00c58')
